require(
	[],

	function () {
        console.log("yo");
        
        // Setting the font family of the article element
        var articleBox = document.getElementById("article");
        articleBox.style.fontFamily = "Charcoal";

        // Setting the text alignment of the header element
        var headerBox = document.getElementById("header");
        headerBox.style.textAlign = "center";
	}
);
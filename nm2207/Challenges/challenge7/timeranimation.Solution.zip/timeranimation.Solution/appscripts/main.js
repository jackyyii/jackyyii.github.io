require(
    [],
    function () {
            
        console.log("yo, I'm alive!");

        var paper = new Raphael(document.getElementById("mySVGCanvas"));
        // Find get paper dimensions
        var dimX = paper.width;
        var dimY = paper.height;

        // maps x in  the interval [a,b] into the interval [m, n]
        var map =function (x, a, b, m, n){
            var range = n-m;
            var proportion = (x-a)/(b-a);
            return (m + proportion*range);
        }

        //--------------------------------
        var frameLength=5; // in ms, used for the interval at which we call the draw() function
        var time = 0;      // time since the page was loaded into the browser; incremented in draw()
        xrate = 0.25;   // ball bounced per second in the x dimension
        yrate = 0.3;   // ball bounces per second in the y dimension

        // Create a dot at the center of the paper
        var dot = paper.circle(dimX/2, dimY/2, 20);

        // give it some attributes
        dot.attr({
                "stroke": "#444444",
                "stroke-width": 2,
                "fill" : "#CCAAFF"        // must be filled to get mouse clicks        
        });


        // function that does the animation, called at the framerate 
        var draw = function(){
                time += frameLength;
                var a = time*2*Math.PI/(1000);
                var sa = Math.sin(xrate*a);
                //console.log("sa is " + sa);
                var px = map(sa, -1, 1, 0, dimX);
                dot.attr({ cx : px});

                var ca = Math.cos(yrate*a);
                var py = map(ca, -1, 1, 0, dimY);
                dot.attr({ cy : py});
        }

        // start the animation
        setInterval(draw,frameLength);

});